package com.example.mobileshop;

import android.app.Activity;
import android.app.AlertDialog;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.widget.*;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private ShopDb db;
    private LinearLayout root, content;
    private final DecimalFormat money = new DecimalFormat("#,##0.00");

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        db = new ShopDb(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(247,248,250));
        TextView header = new TextView(this); header.setText("📱 صيانة الموبايلات"); header.setTextSize(24); header.setTextColor(Color.WHITE);
        header.setGravity(Gravity.CENTER); header.setPadding(12,22,12,22); header.setBackgroundColor(Color.rgb(27,82,120)); root.addView(header);
        LinearLayout nav = new LinearLayout(this); nav.setPadding(5,5,5,5); nav.setBackgroundColor(Color.WHITE);
        addNav(nav, "العملاء والصيانة", () -> showCustomersForm());
        addNav(nav, "المبيعات والمصاريف", () -> showTransactionForm());
        addNav(nav, "التقارير", () -> showReports());
        root.addView(nav);
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setPadding(14,12,14,24); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root); showCustomersForm();
    }
    private void addNav(LinearLayout nav, String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextSize(12); b.setAllCaps(false); b.setOnClickListener(v -> action.run());
        nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
    }
    private TextView title(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(19); t.setTextColor(Color.rgb(27,82,120)); t.setPadding(0,10,0,12); t.setGravity(Gravity.RIGHT); return t;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(15); e.setSingleLine(false); e.setPadding(12,8,12,8);
        e.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,4,0,4); e.setLayoutParams(p); return e;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(27,112,153)));
        b.setOnClickListener(v -> action.run()); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b;
    }
    private void showCustomersForm() {
        content.removeAllViews(); content.addView(title("تسجيل عميل / طلب صيانة"));
        EditText name=field("اسم العميل *"), phone=field("رقم الهاتف"), device=field("نوع الجهاز / الموديل"),
            issue=field("العطل المطلوب إصلاحه"), parts=field("قطع الغيار المستخدمة"), cost=field("إجمالي تكلفة الصيانة (جنيه)"),
            paid=field("المبلغ المدفوع (جنيه)"), status=field("حالة الجهاز: تحت الصيانة / جاهز / تم التسليم");
        content.addView(name); content.addView(phone); content.addView(device); content.addView(issue); content.addView(parts);
        content.addView(cost); content.addView(paid); content.addView(status);
        content.addView(button("حفظ بيانات العميل", () -> {
            String n=name.getText().toString().trim();
            if(n.isEmpty()){ toast("اكتب اسم العميل أولاً"); return; }
            double c=parse(cost.getText().toString()), p=parse(paid.getText().toString());
            long id=db.addCustomer(n,phone.getText().toString(),device.getText().toString(),issue.getText().toString(),parts.getText().toString(),c,p,
                status.getText().toString().trim().isEmpty()?"تحت الصيانة":status.getText().toString());
            if(id>0){toast("تم حفظ بيانات العميل"); showCustomersForm();} else toast("تعذر الحفظ");
        }));
        content.addView(title("آخر طلبات الصيانة"));
        Cursor c=db.customers(); int count=0;
        while(c.moveToNext() && count++<30) {
            String row="العميل: "+c.getString(1)+"\nالهاتف: "+safe(c.getString(2))+" | الجهاز: "+safe(c.getString(3))+
                "\nالعطل: "+safe(c.getString(4))+"\nقطع الغيار: "+safe(c.getString(5))+
                "\nالتكلفة: "+money.format(c.getDouble(6))+" ج.م | المدفوع: "+money.format(c.getDouble(7))+" ج.م"+
                "\nالحالة: "+safe(c.getString(8))+"\nالتاريخ: "+safe(c.getString(9));
            content.addView(record(row));
        } c.close();
        if(count==0) content.addView(note("لا توجد طلبات صيانة مسجلة حتى الآن."));
    }
    private void showTransactionForm() {
        content.removeAllViews(); content.addView(title("تسجيل حركة مالية"));
        Spinner type=new Spinner(this); String[] types={"بيع","شراء","مصروف","إيراد آخر"}; type.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, types));
        content.addView(type);
        EditText title=field("البيان (مثال: بيع شاشة أو شراء شواحن) *"), amount=field("المبلغ بالجنيه *"), note=field("ملاحظات");
        content.addView(title); content.addView(amount); content.addView(note);
        content.addView(button("حفظ الحركة", () -> {
            String t=title.getText().toString().trim(); double a=parse(amount.getText().toString());
            if(t.isEmpty()||a<=0){toast("اكتب البيان ومبلغًا صحيحًا");return;}
            long id=db.addTransaction(type.getSelectedItem().toString(),t,a,note.getText().toString());
            if(id>0){toast("تم حفظ الحركة");showTransactionForm();} else toast("تعذر الحفظ");
        }));
        content.addView(title("آخر الحركات المالية"));
        Cursor c=db.transactions(); int count=0;
        while(c.moveToNext() && count++<40) {
            content.addView(record(c.getString(1)+" — "+c.getString(2)+"\nالمبلغ: "+money.format(c.getDouble(3))+" ج.م\n"+safe(c.getString(4))+"\n"+safe(c.getString(5))));
        } c.close();
        if(count==0) content.addView(note("لا توجد حركات مالية مسجلة."));
    }
    private void showReports() {
        content.removeAllViews(); content.addView(title("التقرير اليومي"));
        Cursor c=db.dailyTotals();
        if(c.moveToFirst()) {
            content.addView(record("طلبات صيانة جديدة اليوم: "+c.getInt(0)));
            content.addView(record("إجمالي المبيعات: "+money.format(c.getDouble(1))+" جنيه"));
            content.addView(record("إجمالي المشتريات: "+money.format(c.getDouble(2))+" جنيه"));
            content.addView(record("إجمالي المصروفات: "+money.format(c.getDouble(3))+" جنيه"));
            content.addView(record("المتبقي على عملاء صيانة اليوم: "+money.format(c.getDouble(4))+" جنيه"));
            double profit=c.getDouble(1)-c.getDouble(2)-c.getDouble(3);
            TextView p=record("صافي الحركة المالية لليوم (المبيعات - المشتريات - المصروفات): "+money.format(profit)+" جنيه");
            p.setTextColor(profit>=0?Color.rgb(20,120,65):Color.RED); content.addView(p);
        } c.close();
        content.addView(note("تنبيه: هذا تقرير مبسط للحركات المسجلة اليوم فقط. لا يشمل تكلفة قطع الغيار المسجلة داخل طلبات الصيانة ضمن حساب صافي الحركة المالية."));
        content.addView(button("تحديث التقرير", () -> showReports()));
    }
    private TextView record(String text) {
        TextView t=new TextView(this); t.setText(text); t.setTextSize(14); t.setTextColor(Color.rgb(45,52,60)); t.setGravity(Gravity.RIGHT);
        t.setPadding(14,12,14,12); t.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,4,0,7); t.setLayoutParams(p); return t;
    }
    private TextView note(String text) { TextView t=record(text); t.setTextColor(Color.GRAY); return t; }
    private double parse(String s) { try { return Double.parseDouble(s.trim().replace(',','.')); } catch(Exception e){ return 0; } }
    private String safe(String s) { return s==null||s.isEmpty()?"—":s; }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    @Override protected void onDestroy(){ if(db!=null) db.close(); super.onDestroy(); }
}
