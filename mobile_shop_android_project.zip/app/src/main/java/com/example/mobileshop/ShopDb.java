package com.example.mobileshop;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ShopDb extends SQLiteOpenHelper {
    public ShopDb(Context context) { super(context, "mobile_shop.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE customers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, device TEXT, issue TEXT, parts TEXT, cost REAL DEFAULT 0, paid REAL DEFAULT 0, status TEXT, created_at TEXT DEFAULT (datetime('now','localtime')))");
        db.execSQL("CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, title TEXT NOT NULL, amount REAL NOT NULL, note TEXT, created_at TEXT DEFAULT (datetime('now','localtime')))");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public long addCustomer(String name, String phone, String device, String issue, String parts, double cost, double paid, String status) {
        ContentValues v = new ContentValues();
        v.put("name", name); v.put("phone", phone); v.put("device", device);
        v.put("issue", issue); v.put("parts", parts); v.put("cost", cost); v.put("paid", paid); v.put("status", status);
        return getWritableDatabase().insert("customers", null, v);
    }
    public long addTransaction(String type, String title, double amount, String note) {
        ContentValues v = new ContentValues();
        v.put("type", type); v.put("title", title); v.put("amount", amount); v.put("note", note);
        return getWritableDatabase().insert("transactions", null, v);
    }
    public Cursor customers() {
        return getReadableDatabase().rawQuery("SELECT id,name,phone,device,issue,parts,cost,paid,status,created_at FROM customers ORDER BY id DESC", null);
    }
    public Cursor transactions() {
        return getReadableDatabase().rawQuery("SELECT id,type,title,amount,note,created_at FROM transactions ORDER BY id DESC", null);
    }
    public Cursor dailyTotals() {
        return getReadableDatabase().rawQuery(
            "SELECT " +
            "(SELECT COUNT(*) FROM customers WHERE date(created_at)=date('now','localtime'))," +
            "(SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='بيع' AND date(created_at)=date('now','localtime'))," +
            "(SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='شراء' AND date(created_at)=date('now','localtime'))," +
            "(SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type='مصروف' AND date(created_at)=date('now','localtime'))," +
            "(SELECT COALESCE(SUM(cost-paid),0) FROM customers WHERE date(created_at)=date('now','localtime'))", null);
    }
}
